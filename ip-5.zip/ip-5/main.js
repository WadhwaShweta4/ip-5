const startstopBtn = document.querySelector('#startstop');

let playing = false;
let playTime;
let correctBoxNumber;
let score;
let timeInterval;

function initialize() {
    startstopBtn.addEventListener('click', handleStartStop);
}

function handleAnswerClick (evt) {
    const currentBoxNumber = evt.target.dataset.position;
    if(currentBoxNumber == correctBoxNumber) {
        score++;
        // playTime = playTime + 3;
        if ( playTime + 3 > 60 ) {
            playTime = 60
        } else playTime = playTime + 3;
        setText('#timeremainingValue', playTime)
        // document.querySelector('#timeremainingValue').textContent = textContent + 5;
        generateQA();
        setText('#scoreValue', score);
        hide('#wrong');
        show('#correct');
        setTimeout( function() {
            hide('#correct');
        }, 500);
    } else {
        playTime = playTime - 5 ;
        setText('#timeremainingValue', playTime)
        score = score - 1;
        setText('#scoreValue', score);
        hide('#correct');
        show('#wrong');
        setTimeout( function() {
            hide('#wrong')
        }, 500);
    }
}

function handleStartStop(evt) {
    if(!playing) { startGame();}
    else { stopGame(); }
}

function startGame() {
    playing = true;
    playTime = 60;
    score = 0;
    hide('#gameover');
    setText('#startstop' ,'Stop Game');
    show('#timeremaining');
    setText('#timeremainingValue', playTime);
    setText('#scoreValue', score);
    generateQA();
    for ( let i = 1; i <= 4; i++) {
        document.querySelector(`#box${i}`).addEventListener('click', handleAnswerClick);
    }

    timeInterval = setInterval( function() {
        playTime--;
        if(playTime <= 0) {
            clearInterval(timeInterval);
            stopGame();
        }
        setText('#timeremainingValue', playTime);
    }, 1000);
}

function stopGame() {
    clearInterval(timeInterval);
    setText('#startstop',  'Start Game');
    setText('#question',  '0 x 0');
    setHTML('#gameover', `<p>Game Over</p> Your Score: ${score}</p>`);
    show('#gameover');
    hide('#timeremaining');
    playing = false;
    for ( let i = 1; i <= 4; i++){
        setText(`#box${i}`, '');
    }
    for ( let i = 1; i <= 4; i++){
        document.querySelector(`#box${i}`).removeEventListener('click', handleAnswerClick);
    }
}

function generateQA() {
    const num1 = getRandomNumber();
    const num2 = getRandomNumber();
    var correctAnswer;
    let random = getRandomNumber(3);

    if ( random == 1) {
        setText('#question', `${num1} x ${num2}`);
        correctAnswer = num1 * num2;
    } else if (random == 2) {
        setText('#question', `${num1} + ${num2}`);
        correctAnswer = num1 + num2;
    } else if ( random == 3) {
        setText('#question', `${num1} - ${num2}`);
        correctAnswer = num1 - num2;
    }

    correctBoxNumber = getRandomNumber(4);
    setText(`#box${correctBoxNumber}`, correctAnswer);

    const answers = [correctAnswer];

    for(let i=1; i <= 4; i++) {
        if(i != correctBoxNumber) {
            let wrongAnswer;
            do {
                const wrongNum1 = getRandomNumber();
                const wrongNum2 = getRandomNumber();

                let rd = getRandomNumber(3);
                if (rd == 1) {
                wrongAnswer = wrongNum1 * wrongNum2; }
                else if ( rd == 2 ) {
                    wrongAnswer = wrongNum1 + wrongNum2;  
                } else if ( rd == 3) {
                    wrongAnswer = wrongNum1 - wrongNum2;
                }
            }while ( answers.indexOf(wrongAnswer) != -1);

            answers.push(wrongAnswer);
            setText(`#box${i}`, wrongAnswer);
        }
    }
}

function getRandomNumber ( max = 10) {
    return (Math.round((Math.random() * (max-1))) + 1);
}

initialize();


function show(selector) {
    document.querySelector(selector).style.display = 'block';
}

function hide(selector) {
    document.querySelector(selector).style.display = 'none';
}

function setText(selector, text) {
    document.querySelector(selector).textContent = text;
}

function setHTML(selector, html) {
    document.querySelector(selector).innerHTML = html;
}